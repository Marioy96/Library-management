package co.develhope.LibraryManagementSoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementSoftwareApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementSoftwareApplication.class, args);
	}

}
